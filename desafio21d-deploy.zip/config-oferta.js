/**
 * ============================================================================
 * CONFIGURAÇÃO CENTRAL DA OFERTA — DESAFÍO DE LOS 21 DÍAS (MARIANA CASTILLO)
 * ============================================================================
 * Edite apenas este arquivo para trocar:
 * 1) ID do Novo Pixel da Meta (META_PIXEL_ID)
 * 2) Código / ID do seu Vídeo VTurb na página /front/ (VTURB_PLAYER_ID e VTURB_SCRIPT_URL)
 * 3) Links de Checkout do Front-End (/lp-b/ e /lp/) e dos Upsells dentro do App (/app/)
 */
window.OFERTA_CONFIG = {
  // 1. SEU NOVO PIXEL DO FACEBOOK ADS (basta colar o número entre as aspas)
  META_PIXEL_ID: "SEU_NOVO_PIXEL_AQUI",

  // 2. SUA VSL DO VTURB (aparece dentro de /front/)
  // Para trocar pelo seu VTurb:
  // - Copie o ID do player (ex: "vid-6ac3f84b1b5253654daa89ba" ou "ab-6ac3f84b1b5253654daa89ba")
  // - Copie a URL do script player.js da ConverteAI/VTurb
  VTURB_PLAYER_ID: "ab-6ac3f84b1b5253654daa89ba",
  VTURB_SCRIPT_URL: "https://scripts.converteai.net/4e6bddd2-27cc-4624-a0e5-16bdbeb9e11f/ab-test/6ac3f84b1b5253654daa89ba/player.js",

  // Se preferir colar o código HTML completo do VTurb (<vturb-smartplayer ...></vturb-smartplayer>),
  // basta preencher VTURB_RAW_HTML abaixo (deixe vazio "" para usar VTURB_PLAYER_ID + VTURB_SCRIPT_URL acima):
  VTURB_RAW_HTML: "",

  // Tempo (em segundos) para exibir um botão extra embaixo da VSL levando para /lp-b/ (0 = desativado, usa só o botão de dentro do VTurb)
  MOSTRAR_BOTAO_ABAIXO_VSL_SEGUNDOS: 0,
  TEXTO_BOTAO_VSL: "QUIERO EMPEZAR EL DESAFÍO DE 21 DÍAS →",

  // 3. LINKS DE CHECKOUT (Hotmart / Kiwify / Cartpanda / Payt)
  CHECKOUT_URL: "https://pay.hotmart.com/S107908101B?off=dmkpp4ku&checkoutMode=10",
  UPSELL1_CHECKOUT_URL: "https://pay.hotmart.com/B107908370A",
  UPSELL2_CHECKOUT_URL: "https://pay.hotmart.com/I107908447H"
};

// Inicializador Automático do Meta Pixel em todas as páginas do funil
(function() {
  var pid = (window.OFERTA_CONFIG && window.OFERTA_CONFIG.META_PIXEL_ID || "").trim();
  if (!pid || pid === "SEU_NOVO_PIXEL_AQUI") return;
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', pid);
  fbq('track', 'PageView');
})();